CREATE TABLE `signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
 `username` varchar(100) NOT NULL,
 `password` varchar(100) NOT NULL,
 `contact` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `product` (
   `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_description` varchar(100) NOT NULL,
  `stock_status` varchar(100) NOT NULL,
  `user_rating` varchar(100) NOT NULL,
 `product_type` varchar(100) NOT NULL,
`image_1` varchar(100) NOT NULL,
`image_2` varchar(100) NOT NULL,
`image_3` varchar(100) NOT NULL

) ENGINE=InnoDB DEFAULT CHARSET=latin1;


