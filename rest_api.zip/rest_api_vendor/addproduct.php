<!-- GITHUB:  https://github.com/Aman-Sharmaa -->

<?php 
$conn=mysqli_connect("localhost","root","","vendor");  
$request=$_SERVER['REQUEST_METHOD'];
 
$data=array();
 switch ($request) {
  case 'GET':
      response(getData());
    break;

 
    case 'POST':
      response(addData());
    break;

     case 'PUT':
      response(updateData());
    break;

      case 'Delete':
      response(removeData());
    break;

  default:
    # code...
    break;
 }




  function getData(){
      global $conn;

      $query=mysqli_query($conn,"select * from product ");

      while ($row=mysqli_fetch_assoc($query)) {
      
        $myARR =  array("id"=>$row['id'],"product_name"=>$row['product_name'],"product_price"=>$row['product_price'],"stock_status"=>$row['stock_status'],"user_rating"=>$row['user_rating'],"image 1"=>$row['image_1'],"image 2"=>$row['image_2'],"image 3"=>$row['image_3']);   

        switch($row['product_type']){

           case "tea" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $myJSON; 
           break;
          case "cofee" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $row['product_type'].$myJSON; 
           break;
            case "tea" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $myJSON; 
           break;
          case "health" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $row['product_type'].$myJSON; 
           break;
            case "chips" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $myJSON; 
           break;
          case "colddrink" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $row['product_type'].$myJSON; 
           break;
            case "biscuits" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $myJSON; 
           break;
          case "rice" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $row['product_type'].$myJSON; 
           break;
            case "dals" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $row['product_type'].$myJSON; 
           break;
            case "oil" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $myJSON; 
           break;
          case "atta" :
           $myARR;
           $myJSON = json_encode($myARR);
           echo "\n";
           echo $row['product_type'].$myJSON; 
           break;


         }

      }
     

   }

function addData(){

  global $conn;

  $query=mysqli_query($conn,"insert into product(product_name,product_price,product_description,stock_status,user_rating,image_1,image_2,image_3)values('".$_POST['product_name']."','".$_POST['product_price']."','".$_POST['product_description']."','".$_POST['stock_status']."','".$_POST['user_rating']."','".$_POST['image_1']."','".$_POST['image_2']."','".$_POST['image_3']."')");

  if ($query==true) {
    $data[]=array("product"=>"successfully added");
  }else{
    $data[]=array("Message"=>"Product add again!");
  }

return $data;
}

function updateData(){
  global $conn;

  parse_str(file_get_contents('php://input'),$_PUT);

   if(@$_GET['id']){
      @$id=$_GET['id'];

      $where="where id=".$id;
     }else{
      $id=0;
      $where="";
     }

     $query=mysqli_query($conn,"update product set product_name='".$_PUT['product_name']."',  product_price='".$_PUT['product_price']."',product_description='".$_PUT['product_description']."',stock_status='".$_PUT['stock_status']."',user_rating='".$_PUT['user_rating']."',image_1='".$_PUT['image_1']."',image_2='".$_PUT['image_2']."',image_3='".$_PUT['image_3']."' ".$where);

      if ($query==true) {
    $data[]=array("Product"=>"update product");
  }else{
    $data[]=array("Message"=>"Not update product!");
  }
   return $data;
}

function removeData(){

     global $conn;
     
     if(@$_GET['id']){
      @$id=$_GET['id'];

      $where="where id=".$id;
     }else{
      $id=0;
      $where="";
     }
     $query=mysqli_query($conn,"delete from product ".$where);

      if ($query==true) {
    $data[]=array("Message"=>"delete product");
  }else{
    $data[]=array("Message"=>"Not delete !");
  }
   return $data;
}


function response($data){

}

 ?>
