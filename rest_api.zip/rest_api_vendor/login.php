<!-- GITHUB:  https://github.com/Aman-Sharmaa -->

<?php 
  define('HOST','localhost');

  define('USER','root');

  define('PASS','');

  define('DB','vendor');


   $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

  if($_SERVER['REQUEST_METHOD']=='POST'){

  $email = $_GET['email'];
  $password = $_GET['password'];
 

  $sql = "SELECT * FROM signup WHERE email='$email' AND password='$password'";

  
  $result = mysqli_query($con,$sql);
  $check = mysqli_fetch_array($result);

  
  if(isset($check))
  {

  echo "message: Login Successful";
   $myARR = array("email"=>$email,"password"=>$password);
   $myJSON = json_encode($myARR);
   echo "\n";
   echo "user data".$myJSON; 
    

  }
  else{

  echo "Wrong Email or Password";

  }

    mysqli_close($con);

  }