<!-- GITHUB:  https://github.com/Aman-Sharmaa -->

<?php

       
 define('HOST','localhost');

  define('USER','root');

  define('PASS','');

  define('DB','vendor');


        $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');


        $username = $_POST['username'];
  $password = $_POST['password'];
  $email = $_POST['email'];
   $name = $_POST['username'];
  $contact = $_POST['password'];
  $address = $_POST['email'];

    if($username == '' || $password == '' || $email == '' ||$name == '' || $contact == '' || $address == '')
    {
  
    echo 'please fill all values';

    }
    else{

    $sql = "SELECT * FROM signup WHERE username='$username' OR email='$email'";

          $check = mysqli_fetch_array(mysqli_query($con,$sql));

    if(isset($check)){

    echo 'username or email already exist';

    }else{
    $sql = "INSERT INTO signup (username,password,email,name,contact,address) VALUES('$username','$password','$email','$name','$contact','$address')";

    if(mysqli_query($con,$sql)){

      echo 'successfully registered';
  
  }
    else{
        
      echo 'oops! Please try again!';
    
    }
}
      
          mysqli_close($con);

    } 